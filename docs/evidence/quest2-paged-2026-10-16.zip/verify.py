"""Independently verify inventory, raw pixel parity, inputs and source hashes.

Run: python verify.py [BUNDLE_DIRECTORY] [OPTIONAL_REPOSITORY]
Runtime geometry-stream assertions remain reproducible browser tests, not claims
that pixel equality alone proves full topology or physical-device qualification.
"""
import base64
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).parent
sha = lambda b: hashlib.sha256(b).hexdigest()
inventory = json.loads((root / 'inventory.json').read_text())
actual = {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.name != 'inventory.json'}
assert actual == set(inventory), 'Inventory membership differs'
for name, item in inventory.items():
    data = (root / name).read_bytes()
    assert len(data) == item['bytes'] and sha(data) == item['sha256'], name
protocol = json.loads((root / 'protocol.json').read_text())
comparisons = 0
for mode in ('surface', 'skeleton'):
    report = json.loads((root / 'software' / mode / 'oracle.json').read_text())
    assert report['status'] == 'pass'
    assert report['fidelity']['selected'] == report['fidelity']['represented'] == 2
    assert report['fidelity']['gpu_ready'] is True
    assert report['source']['dirty'] is False
    assert report['source']['commit'] == protocol['software_capture_commit']
    assert {(c['time'], c['eye']) for c in report['results']} == {(t,e) for t in (0,20,350) for e in (-1,1)}
    assert len(report['results']) == 6
    witnessed = set()
    for case in report['results']:
        assert case['reference_view'] == case['candidate_view'], 'Camera/projection changed'
        assert case['width'] == case['height'] == 256
        for channel in ('colour', 'neuron_id', 'packed_depth'):
            pair = []
            for field in ('reference_images', 'candidate_images'):
                image = case[field][channel]
                pixels = base64.b64decode(image['base64'], validate=True)
                assert len(pixels) == 4 * case['width'] * case['height']
                assert sha(pixels) == image['sha256']
                pair.append(pixels)
            assert pair[0] == pair[1], (mode, case['time'], case['eye'], channel)
            comparisons += 1
            if channel == 'neuron_id':
                ids = {pair[0][i] + 256*pair[0][i+1] + 65536*pair[0][i+2] for i in range(0,len(pair[0]),4)} - {0}
                assert ids == set(case['nonempty_ids']) and ids
                assert ids <= {1,2}
                witnessed.update(ids)
    assert witnessed == {1,2}
    owned = 0
    for page in report['gpu']:
        sizes = {b['name']:b['bytes'] for b in page['buffers']}
        assert sum(sizes.values()) <= 4*1024*1024
        assert sizes['position']//12 == sizes['aNeuron']//4
        arity = 3 if mode == 'surface' else 2
        assert sizes['index'] == sum(s['count'] for s in page['spans'])*arity*4
        if mode == 'surface': assert sizes['normal'] == sizes['position']
        owned += sum(sizes.values())
    assert owned == report['before_reference_resources']['gpu_resources']['owned_gpu_bytes']
    for name, digest in report['source_sha256'].items():
        assert sha((root / 'sources' / 'viz_static' / name).read_bytes()) == digest, name
    if mode == 'skeleton':
        routing = report['diagnostic_routing']
        assert routing['renderer_pipeline'] == 'immutable-pages'
        assert routing['application_state_restored'] is True
        assert routing['gpu_variants'] == 5
        assert routing['direct_frames'] > 0 and routing['desktop_frames'] > 0
    assert len(report['desktop_cases']) == 3
    for case in report['desktop_cases']:
        a, b = case['reference'], case['candidate']
        assert a['samples'] == b['samples'] == 4
        assert a['bloom'] is b['bloom'] is True
        assert a['pixel_ratio'] == b['pixel_ratio']
        assert a['projection'] == b['projection'] and a['camera_world'] == b['camera_world']
        assert a['width'] == b['width'] and a['height'] == b['height']
        pa, pb = (base64.b64decode(x['rgba']['base64'],validate=True) for x in (a,b))
        assert len(pa) == 4*a['width']*a['height'] and pa == pb
        assert sha(pa) == a['rgba']['sha256'] == b['rgba']['sha256']
        assert len(set(pa)) > 2
        comparisons += 1
assert comparisons == 42
core = json.loads((root / 'software' / 'core' / 'oracle.json').read_text())
assert core['status'] == 'pass'
assert core['source']['dirty'] is False
assert core['source']['commit'] == protocol['software_capture_commit']
for name, digest in core['source_sha256'].items():
    assert sha((root / 'sources' / 'viz_static' / name).read_bytes()) == digest, name
assert all(core['worker_contexts'].values())
assert {r['primitiveSize'] for r in core['results']} == {1,2,3}
assert all(r['gpu_stream_exact'] and r['lifecycle_cycles'] == 5 and r['stale_generation_rejected'] and r['contextual_alpha_exact'] for r in core['results'])
assert any(r['context_restored'] for r in core['results'])
if len(sys.argv) > 2:
    repo = Path(sys.argv[2])
    for name, item in protocol['source_files'].items():
        blob = subprocess.check_output(['git','-C',str(repo),'show',f"{protocol['code_commit']}:{name}"])
        assert sha(blob) == item, name
hardware = json.loads((root / 'hardware.json').read_text())
assert hardware['qualification']['surface'] == hardware['qualification']['skeleton'] == 'not-run'
print(f'PASS: {len(inventory)} files; 42 raw RGBA pairs; matching camera/projection; nonempty IDs; source provenance')
print('Physical Quest qualification: NOT RUN. Software fixtures do not qualify full-scene performance.')
