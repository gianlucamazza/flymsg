# Paged renderer software evidence

Run `python verify.py . OPTIONAL_REPOSITORY` after extracting. The verifier checks every inventoried file, raw reference/candidate RGBA, fixed cameras, nonempty IDs and source blobs. The core browser test separately compares original/GPU primitive streams and exercises lifecycle/context recovery.

These are two-neuron software correctness fixtures. Both physical full-scene representation qualifications remain open. Read protocol.json and hardware.json for limits and exact provenance. Native owned-buffer accounting is not total GPU memory.
