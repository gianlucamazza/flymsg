"""Independent artifact verification and arithmetic; never issues an XR pass."""
import hashlib
import json
import re
import statistics
from pathlib import Path

root = Path(__file__).resolve().parent
inventory = json.loads((root / "inventory.json").read_text())
actual = {str(p.relative_to(root)) for p in root.rglob("*") if p.is_file() and p.name != "inventory.json"}
assert actual == set(inventory), "Artifact inventory differs"
for name, digest in inventory.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
load = lambda name: json.loads((root / name).read_text())
summary = {"schema": "flymsg.quest-browser-followup/v1", "qualification": "not-qualified; no eligible XR cadence", "inventory_files": len(inventory)}
for name in ["direct", "desktop"]:
    result = load(f"{name}/probe.json")
    assert result["fidelity"]["selected"] == result["fidelity"]["represented"] == 1128
    assert result["nonuniform_colour"] and result["source_reference_unchanged"]
    assert load(f"{name}/complete.json")["state_restored"]
    source = load(f"{name}/served-sources.json")
    assert source["loaded"] == source["served"]
    assert hashlib.sha256((root / "source/main.js").read_bytes()).hexdigest() == source["loaded"]["main.js"]
    line = next(g for g in result["reference"]["geometry"] if g["type"] == "LineSegments")
    assert line["range"]["count"] // 2 == 8258589
    assert line["index"]["byteLength"] == 66068712
    metrics = {}
    for chunk in load(f"{name}/native.json")["chunks"]:
        if not result["workload_started_at"] < chunk["at"] < result["workload_ended_at"]:
            continue
        for line in chunk["text"].splitlines():
            found = re.match(r"(.+?)\s*:\s*([0-9.]+)$", line)
            if found:
                metrics.setdefault(found[1].strip(), []).append(float(found[2]))
    summary[name] = {
        "samples": len(result["records"]),
        "serialized_wall_median_ms": statistics.median(r["serialized_wall_ms"] for r in result["records"]),
        "system_gpu_counter_medians": {k: statistics.median(v) for k, v in metrics.items()},
        "initial_upload_bytes": sum(u["bytes"] for u in result["uploads"] if u["phase"] == "reference-before"),
        "initial_upload_submission_ms": sum(u["submission_ms"] for u in result["uploads"] if u["phase"] == "reference-before"),
        "steady_upload_bytes": sum(u["bytes"] for u in result["uploads"] if u["phase"] == "dense-steady"),
    }
raster = load("raster/raster.json")
assert raster["status"] == "pass" and raster["comparisons"] == 96 and len(raster["cases"]) == 16
assert raster["cache_released"]
summary["raster"] = {
    "rgba_comparisons": raster["comparisons"],
    "timings": [{"workload": t["workload"], "mode": t["mode"], "order": t["order"],
        "samples": len(t["serialized_wall_ms"]), "serialized_wall_median_ms": statistics.median(t["serialized_wall_ms"])} for t in raster["timings"]],
}
for name in ["software-raster", "software-geometry"]:
    assert load(f"{name}/oracle.json")["status"] == "pass"
assert load("frozen-eligibility.json")["result"]["result"]["value"]["ticks"] == 0
assert "disabled" in (root / "stage-capture/initial-mode.txt").read_text()
assert "disabled" in (root / "stage-capture/final-mode.txt").read_text()
summary["detailed_stage_capture"] = "unavailable; initial disabled mode restored"
print(json.dumps(summary, indent=2))
