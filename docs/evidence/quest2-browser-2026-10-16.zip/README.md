# Quest Browser follow-up, 2026-10-16 (Europe/Rome)

NOT an XR qualification. No eligible frame cadence was collected.

- `direct/`, `desktop/`: clean application source 635c20a, actual loaded module hashes
  equal served hashes via CDP Debugger.getScriptSource. Both preserve all 1,128
  selected neurons / 8,258,589 original segments. One view, 512 square, time 20 ms,
  complete RGBA8 readback. Direct uses zero MSAA, no composer; desktop uses the
  actual existing composer and its 4x MSAA. These are different-quality DIAGNOSTICS,
  never candidates to ship as a quality reduction. Samples include submission,
  driver IPC and readback. Warmup/reference/setup/restore are outside the loop.
- CPU profiles include setup, reference hashing and teardown as well as the loop.
  Samples in readPixels are blocked wall time, not proof of equivalent CPU work.
- Native realtime counters are SYSTEM-WIDE one-second samples. Attribute only
  the overlapping active-loop interval approximately; do not infer exclusive
  per-pass GPU times or headset refresh. Native timeout code 124 is intentional.
- First direct reference preparation uploaded 203,647,016 bytes through five
  bufferData calls; their measured submission wall total is about 463.1 ms.
  This was cold offscreen GPU initialization while application rAF was suspended,
  not a measured first visible browser frame. The desktop reference transition
  also reuploaded its 66,068,712-byte index outside the measured steady loop.
- `raster/`: independent frozen drawRaster from 63c63d6, not candidate helpers.
  96 complete RGBA comparisons cover 16 layout/DPR/row-count cases and six time
  transitions, including repeated bins and scrubbing backwards. Synthetic 40-row,
  60-bin fixture matches the real replay shape; it is not a captured biological
  spike selection. A/B/B/A canvas timings include identical sink readback and
  compare repeated-bin and every-bin-change workloads. Timings are exploratory.
  Source canvases are read through separate sinks so Chromium's readback migration
  heuristic cannot move only the redrawn implementation from GPU to CPU raster.
- `software-raster/`: 96 comparisons on explicit CPU Canvas2D; correctness only.
  The later 0d4c854 commit only adds that diagnostic backend choice to the oracle
  and runner. Production main/painter are byte-identical to the hardware version.
- `software-geometry/`: independent full-source versus resident/cached WebGL
  colour/ID/depth, six camera cases; SwiftShader correctness only, clean 635c20a.
- `frozen-eligibility.json`: visible document but ZERO rAF callbacks in two seconds.
  No FPS, thermal, memory plateau or immersive verdict is possible.
- `stage-capture/`: detailed profiling was briefly enabled and the browser restarted.
  CDP did not return in either detailed or restored normal mode. No render-stage
  trace was obtained. Driver profiling restored to disabled, as initially found.
  The original local URL was requested again; visible page restoration is unverified.
  No refresh/clock/proximity/foveation/resolution safety override was used.

Collectors: `ANDROID_ADB_SERVER_PORT=5038 node scripts/observer_browser.mjs
http://localhost:40623 TARGET NEW_DIRECTORY QUEST_SERIAL [direct|desktop]` and
`node scripts/observer_raster.mjs http://localhost:40623 TARGET NEW_DIRECTORY`.
They require an explicit local ?check observer, complete anatomy, immutable output,
and restored observer state. CPU profiles are target-scoped. No other tabs are inspected.

Run `python verify.py` after extraction. This validates artifact hashes and recomputes
reported summaries; it deliberately does not issue an XR or preregistered performance pass.
