import hashlib
import json
import subprocess
import sys
import urllib.request
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from quest_xr import browser_endpoint

root=Path('/home/gianluca/.cache/flymsg/evidence/bounded-runtime-febbfc2-matrix')
viewer=json.loads((root/'viewer.json').read_text())
if viewer['gpu_page_mib']!=16:raise RuntimeError('Expected stable 16 MiB correctness document')
out=Path('/home/gianluca/.cache/flymsg/evidence/bounded-febbfc2-readback-16-a81cd5b')
assert not out.exists()
metadata={'qualification':'static correctness only; no cadence or XR admission','runtime_commit':'febbfc285969ac7d433ed21c59fc0a3bd8661fb6','host_verifier_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'url':viewer['url'],'verifier_sha256':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in ['scripts/observer_oracle.mjs','scripts/observer_preflight.mjs','scripts/observer_cdp.mjs']}}
with browser_endpoint('192.168.1.146:5555') as endpoint:
    with urllib.request.urlopen(endpoint+'/json/list') as response:pages=json.load(response)
    matches=[p for p in pages if p.get('url')==viewer['url']]
    if len(matches)!=1:raise RuntimeError('Exact owned document not unique')
    command=['node','scripts/observer_oracle.mjs',endpoint,matches[0]['id'],str(out),'--readback-only']
    with open('/tmp/flymsg-independent-bounded-readback.log','w') as stream:
        result=subprocess.run(command,text=True,stdout=stream,stderr=subprocess.STDOUT,timeout=1000)
if out.exists():
    with (out/'host-runtime-provenance.json').open('x') as stream:json.dump(metadata,stream,indent=2)
    (out/'diagnostic-script.py').write_bytes(Path(__file__).read_bytes())
raise SystemExit(result.returncode)
