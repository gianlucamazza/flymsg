import base64,hashlib,json,pathlib
from array import array
root=pathlib.Path(__file__).parent
report={"status":"running","qualification":"independent offline raster support and artifact integrity; geometry proof not recomputed","cases":[]}
def pixels(d):
 b=base64.b64decode(d["base64"],validate=True)
 assert hashlib.sha256(b).hexdigest()==d["sha256"],"image hash mismatch"
 return b
def check(a,b,ids,w,h,r):
 a,b,ids=map(pixels,(a,b,ids)); assert len(a)==len(b)==len(ids)==w*h*4
 rx,ry=r["x"],r["y"]; changed=0
 # Independent summed-area table of original nonzero neuron ID pixels.
 stride=w+1; summed=array('I',[0])*((w+1)*(h+1))
 for y in range(h):
  row=0
  for x in range(w):
   j=(y*w+x)*4;row+=bool(ids[j] or ids[j+1] or ids[j+2])
   summed[(y+1)*stride+x+1]=summed[y*stride+x+1]+row
 for i in range(w*h):
  if a[i*4:i*4+4]==b[i*4:i*4+4]: continue
  changed+=1; x,y=i%w,i//w
  x0,x1=max(0,x-rx),min(w,x+rx+1);y0,y1=max(0,y-ry),min(h,y+ry+1)
  support=summed[y1*stride+x1]-summed[y0*stride+x1]-summed[y1*stride+x0]+summed[y0*stride+x0]
  assert support>0,"changed pixel outside original stroke support"
 return changed
oracle=json.loads((root/"oracle.json").read_text());assert oracle["status"]=="pass"
assert oracle["selected_neurons"]==1128 and oracle["primitive_count"]==8258589
for case in oracle["cases"]:
 t,e=case["time"],case["eye"]
 a=json.loads((root/f"reference-{t}-{e}.json").read_text());b=json.loads((root/f"candidate-{t}-{e}.json").read_text())
 for name in ["neuron_id","packed_depth"]: assert pixels(a["images"][name])==pixels(b["images"][name])
 n=check(a["images"]["colour"],b["images"]["colour"],a["images"]["neuron_id"],a["width"],a["height"],{"x":2,"y":2})
 assert n==case["footprint"]["changed_pixels"]
 report["cases"].append({"time":t,"eye":e,"changed_pixels":n})
for t in [0,20,350]:
 d=json.loads((root/f"desktop-{t}.json").read_text());a,b=d["original"],d["candidate"]
 assert a["samples"]==b["samples"] and a["camera_world"]==b["camera_world"] and a["projection"]==b["projection"]
 n=check(a["rgba"],b["rgba"],d["source_neuron_id"],a["width"],a["height"],d["footprint"]["radius"])
 assert n==d["footprint"]["changed_pixels"]
 report["cases"].append({"time":t,"desktop":True,"changed_pixels":n,"radius":d["footprint"]["radius"]})
report["status"]="pass"
(root/"offline-raster-audit.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report))
