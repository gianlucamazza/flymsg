import hashlib,json,sys
from pathlib import Path
r=Path(sys.argv[1]);d=json.loads((r/'report.json').read_text());inv=json.loads((r/'inventory.json').read_text())
for name,sha in inv.items(): assert hashlib.sha256((r/name).read_bytes()).hexdigest()==sha,name
assert d['passed'] and d['fixture']['extension']=='both' and d['fixture']['steps']==1000000
assert d['cancel']['ok'] and d['stop_and_resume']['ok'] and d['stop_and_resume']['parked_as']=='suspended'
assert d['stop_and_resume']['parked_at_step']+d['stop_and_resume']['resumed_advance_steps']==1000000
h=[]
for p in r.glob('*/result.json'):
 x=json.loads(p.read_text());o=p.with_name('output.bin');s=hashlib.sha256(o.read_bytes()).hexdigest();assert s==x['output_sha256'];h.append(s)
assert len(h)==2 and len(set(h))==1
print('Raw archive integrity and byte-identical uninterrupted/resumed completion verified')
