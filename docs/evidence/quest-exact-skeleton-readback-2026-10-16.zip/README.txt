Exact original skeleton static readbacks; Quest 2; clean runtime cf068d955b15af2b666f2718dbda002508704a3a.
This immutable snapshot includes only the completed 4 MiB readback phase. The parent campaign remains separate and may still run. It does not include a completed session cleanup receipt or any cadence admission.
All 1128 selected neurons and 8258589 original segments are represented. Six two-eye timestamp captures compare original and paged colour/depth/ID byte for byte. Three desktop captures compare full-quality colour byte for byte.
Replay: python independent/audit.py readbacks
The independent replay checks pixel hashes/bytes, camera/quality identities and reported source span coverage. It does not recompute native GPU buffer hashes or prove continuous native focus, physical stereo comfort, frame cadence or XR qualification. Static readback-only readiness deliberately cannot authorize cadence or XR.
Negative controls reject a broken image hash, a changed colour byte with a recomputed hash, and a source-coverage gap. Native Guardian focus excluded cadence readiness during collection; it does not invalidate this explicitly static readback profile or qualify performance.
progress.json may retain an intermediate state; oracle.json is the final static verdict. readbacks/cleanup.json concerns only diagnostic state restoration, not the parent session's owned-resource cleanup.
Check out the exact runtime commit for the complete implementation/source assets. Source SHA-256 attestations and original scene/activity identities are retained in the raw receipts.
