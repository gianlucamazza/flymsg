"""Independent replay of saved exact pixels and reported original primitive spans.

Does not import renderer code or recompute native GPU buffer hashes. Not cadence,
physical stereo comfort, or a hardware performance qualification.
"""
import base64
import hashlib
import json
import sys
from pathlib import Path


def pixels(image):
    raw = base64.b64decode(image['base64'], validate=True)
    assert hashlib.sha256(raw).hexdigest() == image['sha256'], 'pixel hash mismatch'
    return raw


def audit(root):
    def read(name):
        return json.loads((root / name).read_text())
    oracle = read('oracle.json')
    assert oracle['status'] == 'pass'
    assert oracle['representation'] == 'skeleton'
    assert oracle['selected_neurons'] == 1128
    assert oracle['primitive_count'] == 8258589
    expected = read('original-primitive-counts.json')
    assert len(expected) == 1128 and sum(expected.values()) == 8258589
    covered = {key: 0 for key in expected}
    for page in read('gpu-inventory.json'):
        for span in page['spans']:
            if span['source'] not in expected:
                continue  # Context is separately present in colour/depth captures.
            assert span['first'] == covered[span['source']], 'gap or overlap'
            assert type(span['count']) is int and span['count'] > 0
            covered[span['source']] += span['count']
    assert covered == expected
    cases = []
    for time in (0, 20, 350):
        for eye in (-1, 1):
            a, b = [read(f'{mode}-{time}-{eye}.json') for mode in ('reference', 'candidate')]
            for key in ('width', 'height', 'time_ms', 'projection', 'camera_world', 'data_world', 'settings', 'scene_sha256', 'activity_sha256'):
                assert a[key] == b[key], f'{key} mismatch'
            for channel in ('colour', 'neuron_id', 'packed_depth'):
                left, right = [pixels(x['images'][channel]) for x in (a, b)]
                assert len(left) == a['width'] * a['height'] * 4
                assert left == right, f'{channel} differs'
            cases.append({'time_ms': time, 'eye': eye, 'exact_channels': 3})
        desktop = read(f'desktop-{time}.json')
        a, b = desktop['original'], desktop['candidate']
        for key in ('width', 'height', 'samples', 'pixel_ratio', 'bloom', 'projection', 'camera_world'):
            assert a[key] == b[key], f'desktop {key} mismatch'
        left, right = pixels(a['rgba']), pixels(b['rgba'])
        assert len(left) == a['width'] * a['height'] * 4
        assert left == right, 'desktop colour differs'
        cases.append({'time_ms': time, 'desktop_exact_colour': True})
    return {'status': 'pass', 'selected_neurons': 1128, 'source_segments': 8258589,
            'cases': cases, 'qualification': 'saved raster bytes and reported primitive span coverage only; no native buffer hash recomputation, cadence or physical XR admission'}


if __name__ == '__main__':
    print(json.dumps(audit(Path(sys.argv[1])), indent=2))
