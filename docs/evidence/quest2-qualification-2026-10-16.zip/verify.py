import hashlib,json,math,sys
from pathlib import Path
r=Path(sys.argv[1]);inv=json.loads((r/'inventory.json').read_text())
for n,h in inv.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
x=json.loads((r/'xr-before-keepawake.json').read_text());v=sorted(x['raw_intervals_ms']);hz=x['timing']['refresh_hz'];assert hz==90
q={f'p{p}':v[min(len(v)-1,math.floor(p/100*len(v)))] for p in (50,95,99)}
assert q==x['timing']['intervals_ms'];budget=1000/hz;missed=sum(max(0,math.floor(t/budget+0.5)-1) for t in v)
assert missed==x['timing']['estimated_missed_slots'];fraction=missed/(len(v)+missed);assert fraction==x['timing']['estimated_missed_fraction']
assert not(q['p95']<=1.1*budget and q['p99']<=2*budget and fraction<=0.01);assert x['content']['incomplete_frames']==0
y=json.loads((r/'final-direct-report.json').read_text())['xr'];assert y['timing']['refresh_hz'] is None and y['timing']['verdict']=='indeterminate'
z=json.loads((r/'empty-desktop-trial.json').read_text());assert not z['raw_intervals_ms'] and not z['eligibility']['visible']
print('90 Hz partial session fails timing; full content retained; mixed-refresh aggregate and zero-callback trial remain unqualified')
