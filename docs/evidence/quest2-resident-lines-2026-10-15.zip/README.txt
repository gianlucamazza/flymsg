Resident-line component evidence, 2026-10-15

Accepted frozen application: d0c461077cd877702eaf1feb128fcbd6e9292a35.
Run: python accepted/verify.py
The verifier reproduces component admission arithmetic from raw samples.
It does NOT score immersive refresh, GPU stage duration or motion-to-photon latency.

accepted/: original geometry/shaders, actual scheduler, compact/resident/resident/compact order; zero measured resident index uploads. Warmups retained separately.
context/: one synthetic direct-render non-immersive context loss/recovery.
frozen/: exact prior camera/time comparison with original 8a76f6a outputs.
oracle.json: six independent synthetic WebGL raster cases, including cached indices.
rejected-native/: WEBGL_multi_draw prototype (not a native Android renderer), rejected for close-static regression.
rejected-groups-only/: public groups without compact cache, rejected for close-static regression.
invalid-capability-mask.json: failed shader diagnostic; no performance result.
frameclock.json: ineligible trial; no callback intervals or XR qualification. Its renderer counters are not per-frame measurements.
native-samples.json: available GPU-clock/raw-busy/thermal and per-process RSS samples; no utilization/reset interpretation. Shared RSS must not be summed as unique physical memory.

Every file except this inventory is checksummed in inventory.json.
Final production vendor renderer is unmodified upstream Three r170.
