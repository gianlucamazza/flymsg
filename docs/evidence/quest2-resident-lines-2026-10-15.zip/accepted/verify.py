"""Independent arithmetic/invariant checks for the recorded component trial, not XR qualification."""
import json
import statistics
from pathlib import Path

root = Path(__file__).parent
d = json.loads((root / 'probe.json').read_text())
assert d['restoration_reference_identical']
assert d['before']['fidelity']['status'] == 'ready'
assert d['before']['fidelity']['selected'] == d['before']['fidelity']['represented'] == 1128
assert all(n['skeleton_level'] == 0 for n in d['source_reference']['neurons'])
assert len(d['references']) == 4 and all(r['nonempty_neuron_id'] for r in d['references'])
assert len(d['records']) == 16
rows = []
for r in d['records']:
    s = r['samples']
    assert len(s) == d['repeats']
    assert all(x['different_colour_bytes'] == 0 for x in s)
    if r['mode'] == 'resident':
        assert all(x['index_upload_bytes'] == x['index_upload_calls'] == 0 for x in s)
        assert all(x['submission']['draws'] <= 8 for x in s)
    rows.append({'view': r['name'], 'mode': r['mode'], 'order': r['order'],
        'selection_ms': statistics.median(x['selection_ms'] for x in s),
        'serialized_wall_ms': statistics.median(x['serialized_wall_ms'] for x in s),
        'mean_index_upload_bytes': statistics.mean(x['index_upload_bytes'] for x in s),
        'backends': sorted({x['submission'].get('backend', 'reference') for x in s})})
for name in ('dense-all', 'close-static', 'anatomical-motion', 'close-motion'):
    r = sorted((x for x in rows if x['view'] == name), key=lambda x:x['order'])
    for control, candidate in ((r[0],r[1]),(r[3],r[2])):
        if name in ('dense-all','close-static'):
            assert candidate['serialized_wall_ms'] <= 1.1 * control['serialized_wall_ms']
        else:
            assert candidate['selection_ms'] < control['selection_ms']
            assert candidate['serialized_wall_ms'] < control['serialized_wall_ms']
print(json.dumps({'component_admission':'pass', 'xr_qualification':'not-scored', 'rows':rows,
    'managed_cpu_bytes_after':d['after']['resources']['managed_geometry_cpu_bytes'],
    'warmup': [{'view':r['name'],'mode':r['mode'],'order':r['order'],
        'max_wall_ms':max(x['serialized_wall_ms'] for x in r['warmup_samples']),
        'index_upload_bytes':sum(x['index_upload_bytes'] for x in r['warmup_samples'])} for r in d['records']]},indent=2))
