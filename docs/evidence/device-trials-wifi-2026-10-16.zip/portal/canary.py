"""Two bounded Portal canaries; no deployment or worker stop."""
import hashlib
import json
import sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from console_gpu_parity import fixtures
from console_lifecycle import Job
from flymsg import manifest, runstore
from flymsg.console import Portal, PortalError

out=Path('/home/gianluca/.cache/flymsg/evidence/portal-wifi-trials-20261016')
out.mkdir(parents=True,exist_ok=False)
package='GianlucaMazza.FlymsgWorker_0.1.0.0_x64__g0p5dcfz4t9z4'
shader=Path('/home/gianluca/.cache/flymsg/xbox/run-38862814877/ci-layout/Assets/lif.cso')
sha=hashlib.sha256(shader.read_bytes()).hexdigest()
assert sha=='957a1202cb387b6ea29617c0865978e5fb1dbbbcaf93cf9f4a0e4e0478f41b14'
p=Portal()
packages=json.loads(p.curl('GET','/api/app/packagemanager/packages'))['InstalledPackages']
assert any(row['PackageFullName']==package for row in packages)
runstore.atomic_json(out/'protocol.json',{'source':manifest.git_info(),'package':package,'shader_sha256':sha,'installed_binary_independently_downloaded':False,'extensions':['none','both'],'scope':'synthetic transport regression canaries; no new lifecycle or biological qualification','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
items=json.loads(p.curl('GET',f'/api/filesystem/apps/files?knownfolderid=LocalAppData&packagefullname={package}&path=%5CLocalState%5Cinbox'))['Items']
status_rows=[]
for item in items:
    rel='inbox\\'+item['Name']
    path=out/'existing-status.json'
    try:
        p.get(package,rel,'status.json',path)
    except PortalError as exc:
        if exc.http_status==404: continue
        raise
    status=json.loads(path.read_text())
    status_rows.append({'job':item['Name'],'state':status.get('state')})
    if status.get('state') not in ('completed','failed','cancelled','suspended','awaiting_recovery'):
        raise RuntimeError('Existing worker job is not terminal; refusing canaries')
runstore.atomic_json(out/'existing-jobs.json',status_rows)
results=[]
for ext in ('none','both'):
    _, rt=next(fixtures((ext,)))
    job=Job(p,package,sha,out,rt,scope='Portal regression canary; synthetic')
    job.submit()
    # Exercise the verified-existing-directory branch on the exact same job folder.
    p.mkdir(package,job.rel)
    status=job.wait({'completed','failed','cancelled'},timeout_s=120)
    passed=status.get('state')=='completed' and job.parity()
    results.append({'extension':ext,'job_id':job.id,'state':status.get('state'),'parity':passed})
    runstore.atomic_json(out/'canaries.json',{'passed':all(r['parity'] for r in results),'cases':results})
    if not passed: raise RuntimeError('Canary failed')
print(json.dumps({'passed':True,'cases':results}))
