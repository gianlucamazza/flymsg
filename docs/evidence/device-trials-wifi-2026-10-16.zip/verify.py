"""Verify immutable trial evidence; optionally reconstruct both tiny CPU canaries."""
import argparse
import hashlib
import json
import sys
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--cpu',type=Path)
a=p.parse_args()
root=Path(__file__).resolve().parent
checks=json.loads((root/'checksums.json').read_text())
for name,sha in checks.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,name
canaries=json.loads((root/'portal/canaries.json').read_text())
assert canaries['passed'] and {r['extension'] for r in canaries['cases']}=={'none','both'}
for case in canaries['cases']:
    folder=root/'portal'/case['job_id']
    assert case['parity'] and case['state']=='completed'
    result=json.loads((folder/'result.json').read_text())
    assert hashlib.sha256((folder/'output.bin').read_bytes()).hexdigest()==result['output_sha256']
    job=json.loads((folder/'job.json').read_text())
    assert hashlib.sha256((folder/'fixture.bin').read_bytes()).hexdigest()==job['fixture_sha256']
    if a.cpu:
        sys.path[:0]=[str(a.cpu/'src'),str(a.cpu/'scripts')]
        from console_gpu_parity import fixtures,check,read_output
        _,rt=next(fixtures((case['extension'],)))
        rt.advance_to(1000)
        check(rt,read_output(folder/'output.bin',folder/'fixture.bin'))
for path in (root/'software').glob('*/oracle.json'):
    assert json.loads(path.read_text())['status']=='pass',str(path)
for path in (root/'quest').glob('*/cleanup.json'):
    assert json.loads(path.read_text())['ok'],str(path)
print(json.dumps({'checksummed_files':len(checks),'portal_canaries':2,'cpu_reverified':bool(a.cpu),'xr_qualified':False}))
# Independently check the device readback files and primitive span partition.
import base64
import math
oracles=0
for path in (root/'quest').rglob('oracle.json'):
    if json.loads(path.read_text()).get('schema') != 'flymsg.observer-hardware-oracle/v1':
        continue
    directory=path.parent
    report=json.loads(path.read_text())
    assert report['status']=='pass' and len(report['cases'])==6
    expected=json.loads((directory/'original-primitive-counts.json').read_text())
    inventory=json.loads((directory/'gpu-inventory.json').read_text())
    for source,count in expected.items():
        spans=sorted((s['first'],s['count']) for page in inventory for s in page['spans'] if s['source']==source)
        cursor=0
        for first,size in spans:
            assert first==cursor and size>0
            cursor+=size
        assert cursor==count
    assert sum(expected.values())==report['primitive_count']
    for time in (0,20,350):
        for eye in (-1,1):
            reference=json.loads((directory/f'reference-{time}-{eye}.json').read_text())
            candidate=json.loads((directory/f'candidate-{time}-{eye}.json').read_text())
            for name,image in reference['images'].items():
                other=candidate['images'][name]
                assert hashlib.sha256(base64.b64decode(image['base64'])).hexdigest()==image['sha256']
                assert hashlib.sha256(base64.b64decode(other['base64'])).hexdigest()==other['sha256']
                assert image['sha256']==other['sha256']
        desktop=json.loads((directory/f'desktop-{time}.json').read_text())
        assert desktop['original']['rgba']['sha256']==desktop['candidate']['rgba']['sha256']
    oracles+=1
for path in (root/'quest').glob('*/page-*/arm-*/trial.json'):
    record=json.loads(path.read_text())
    values=sorted(record['raw_intervals_ms'])
    assert len(values)>=20 and record['intervals_ms']['p95']==values[math.ceil(len(values)*0.95)-1]
    assert record['identity']['samples']==4 and record['identity']['pixel_ratio']==1
print(json.dumps({'complete_hardware_readback_oracles':oracles,'xr_qualified':False}))
# A performance veto requires three complete ABBA blocks, independently recomputed.
import statistics
for path in (root/'quest').glob('*/mandatory-veto.json'):
    record=json.loads(path.read_text())
    ratios=[]
    for repeat in range(3):
        directories=list(path.parent.glob(f'page-4-dense-all-repeat-{repeat}-attempt-*'))
        successful=[d for d in directories if (d/'block.json').exists()]
        assert len(successful)==1
        p95=[]
        for arm,mode in enumerate(('original','paged','paged','original')):
            trial=json.loads((successful[0]/f'arm-{arm}-{mode}/trial.json').read_text())
            assert trial['eligible'] and not trial['reasons']
            values=sorted(trial['raw_intervals_ms'])
            p95.append(values[math.ceil(0.95*len(values))-1])
        ratios.append(statistics.median(p95[1:3])/statistics.median([p95[0],p95[3]]))
    assert ratios==record['ratios'] and statistics.median(ratios)>1.10
    assert not record['admitted'] and len(record['unmeasured_views'])==3
print(json.dumps({'mandatory_veto_checks':'pass','no_early_positive_admission':True}))
# Stage probes are artificial completed-image diagnostics, not headset frame time.
stages=0
for path in (root/'quest').glob('quest-performance-stages-*/*/probe.json'):
    row=json.loads(path.read_text())
    assert row['nonuniform_colour'] and row['source_reference_unchanged']
    assert row['fidelity']['selected']==row['fidelity']['represented']==1128
    assert row['fidelity']['status']=='ready'
    assert row['records'] and all(math.isfinite(r['serialized_wall_ms']) and r['serialized_wall_ms']>0 for r in row['records'])
    assert json.loads((path.parent/'complete.json').read_text())['state_restored']
    stages+=1
# Both versions of the geometric oracle and actual draw counts remain inspectable.
bounded=0
for path in (root/'quest').glob('quest-bounded-*/[dc]*/experiment.json'):
    row=json.loads(path.read_text())
    assert row['normal_xr_qualification'] is False and row['original_reference_unchanged']
    assert row['error_contract_px']==.5 and len(row['eyes'])==3
    assert len(row['neurons'])==len(row['original_reference']['neurons'])==1128
    assert sum(n['original_edges'] for n in row['neurons'])==8258589
    assert all(math.isfinite(n['maximum_error_px']) and 0<=n['maximum_error_px']<=.5 for n in row['neurons'])
    assert row['render_settings']=={'pixel_ratio':1,'samples':4,'bloom':True}
    if 'original_rgba_base64' in row['images']:
        pixels={mode:base64.b64decode(row['images'][mode+'_rgba_base64']) for mode in ('original','bounded')}
        for mode,raw in pixels.items():
            assert len(raw)==4*row['width']*row['height']
            assert hashlib.sha256(raw).hexdigest()==row['images'][mode+'_sha256']
        changed=sum(pixels['original'][i:i+4]!=pixels['bounded'][i:i+4] for i in range(0,len(pixels['original']),4))
        assert changed==row['images']['changed_pixels']
    ratios=[]
    for block in row['blocks']:
        assert [arm['mode'] for arm in block['arms']]==['original','bounded','bounded','original']
        med=[]
        for arm in block['arms']:
            samples=arm['serialized_wall_ms']
            assert len(samples)==8 and all(math.isfinite(x) and x>0 for x in samples)
            med.append(statistics.median(samples))
            if 'submitted_lines' in arm:
                key='original_edges' if arm['mode']=='original' else 'candidate_edges'
                assert arm['submitted_lines']==sum(n[key] for n in row['neurons'])
        ratios.append(statistics.median(med[1:3])/statistics.median([med[0],med[3]]))
    assert len(ratios)==3 and all(x<=.9 for x in ratios)
    assert json.loads((path.parent/'complete.json').read_text())['state_restored']
    bounded+=1
for path in (root/'quest').glob('*/proximity-restored.json'):
    row=json.loads(path.read_text())
    assert row['state']=='DISABLED' and row['locks']==[0,0,0]
print(json.dumps({'native_stage_probes':stages,'bounded_fixed_view_experiments':bounded,'normal_xr_qualified':False,'production_mode_admitted':False,'geometric_limit_scope':'independent in-browser verifier retained by source hash; this offline pass verifies reports and raw timings, not reconstructed source paths'}))
