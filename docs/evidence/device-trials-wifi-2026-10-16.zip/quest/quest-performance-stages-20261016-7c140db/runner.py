import sys,json,subprocess,shutil
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from quest_xr import QuestSite, snapshot
out=Path(sys.argv[1])
session=QuestSite('192.168.1.146:5555',out,port=8892,keep_awake=True,wifi_only=True,unattended=True)
with session:
 shutil.copyfile(__file__,out/'runner.py')
 session.record('diagnostic-protocol.json',{'mode':'unattended desktop stage isolation','seconds_per_probe':8,'size':512,'order':['original','paged16','paged64'],'pipelines':['direct','desktop'],'normal_xr_qualification':False,'decision_rule':'No admission from serialized probes. Reject any nonidentical reference, incomplete content, hidden page or failed restore. Only output-equivalent optimizations with repeated >=10 percent gain may proceed to cadence.'})
 rows=[]
 for size,uploads in [(4,False),(16,True),(64,True)]:
  label=f'paged{size}' if uploads else 'original'
  try:
   session.open(representation='skeleton',page_mib=size,uploads=uploads,culling=False)
   ready=session.wait_ready(timeout=600,evidence=out/f'{label}-preflight.jsonl')
   if not ready['eligible']: raise RuntimeError(str(ready['reasons']))
   if uploads:
    subprocess.run(['node','scripts/observer_oracle.mjs',session.endpoint,session.target,str(out/f'{label}-oracle')],check=True,stdout=(out/f'{label}-oracle.log').open('w'),stderr=subprocess.STDOUT,timeout=240)
   for pipeline in ('direct','desktop'):
    session.record(f'{label}-{pipeline}-before.json',snapshot(session.serial))
    result=subprocess.run(['node','scripts/observer_browser.mjs',session.endpoint,session.target,str(out/f'{label}-{pipeline}'),session.serial,pipeline],stdout=(out/f'{label}-{pipeline}.log').open('w'),stderr=subprocess.STDOUT,timeout=240)
    rows.append({'configuration':label,'pipeline':pipeline,'returncode':result.returncode})
    session.record(f'{label}-{pipeline}-after.json',snapshot(session.serial))
    session.record('stages-progress.json',{'results':rows})
  except Exception as exc:
   rows.append({'configuration':label,'error':str(exc)})
   session.record('stages-progress.json',{'results':rows})
 session.record('stages-complete.json',{'results':rows,'normal_xr_qualification':False})
