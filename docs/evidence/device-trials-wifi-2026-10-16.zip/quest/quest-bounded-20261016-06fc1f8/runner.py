import sys,subprocess,shutil
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from quest_xr import QuestSite
out=Path(sys.argv[1]);session=QuestSite('192.168.1.146:5555',out,port=8892,keep_awake=True,wifi_only=True,unattended=True)
with session:
 shutil.copyfile(__file__,out/'runner.py')
 session.open(representation='skeleton',uploads=False,culling=False)
 ready=session.wait_ready(timeout=600,evidence=out/'preflight.jsonl')
 if not ready['eligible']:raise RuntimeError(str(ready['reasons']))
 results=[]
 for view in ('dense','close'):
  result=subprocess.run(['node','scripts/observer_bounded.mjs',session.endpoint,session.target,str(out/view),view],stdout=(out/f'{view}.log').open('w'),stderr=subprocess.STDOUT,timeout=240)
  results.append({'view':view,'returncode':result.returncode});session.record('experiment-progress.json',{'results':results})
  if result.returncode:break
 session.record('experiment-complete.json',{'results':results,'normal_xr_qualification':False})
