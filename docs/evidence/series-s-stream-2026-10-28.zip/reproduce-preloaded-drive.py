import hashlib
import itertools
import json
import os
from pathlib import Path
import time

import numpy as np
from scipy import sparse
from flymsg import sim
from flymsg.console import Portal
from flymsg.console_hardstop import processes
from flymsg.console_lifecycle import Job, app_call
from flymsg.native_acceptance import MEMBRANE
from flymsg.runtime import CpuRuntime

p = Portal()
package = 'GianlucaMazza.FlymsgWorker_0.1.0.1_x64__g0p5dcfz4t9z4'
aumid = 'GianlucaMazza.FlymsgWorker_g0p5dcfz4t9z4!App'
source = '3cfa17f5c2d2247bef7ab7d5ae9dc212c2801817'
shader_sha = hashlib.sha256(Path(os.environ['FLYMSG_WORKER_SHADER']).read_bytes()).hexdigest()
out = Path('runs/physical-preloaded-drive-parity')
out.mkdir(exist_ok=False)
graded = sim.Graded(idx=np.array([0, 1, 5, 6]), v_lo=-62, span=20, rate_hz=np.array([200,300,150,300]))
features = {'none':{}, 'graded-input':{'graded':graded}, 'membrane':{'membrane':MEMBRANE},
            'graded-input-membrane':{'graded':graded, 'membrane':MEMBRANE}}
cases=[]
report=dict(schema='flymsg.console_preloaded_drive/v1',source_commit=source,package=package,
            shader_sha256=shader_sha,expected_cases=16,cases=cases,qualified=False,
            scope='synthetic preloaded float32 drive, dense/sparse; not biological validation or throughput')
try:
    assert not processes(p, 'FlymsgWorker.exe')
    app_call(p, 'POST', package, aumid)
    for seed, storage, extension in itertools.product((91,127),('dense','sparse'),features):
        rng = np.random.default_rng(seed)
        W = sparse.csc_matrix(rng.integers(-20,80,(8,8)).astype(np.float32))
        values = rng.uniform(0,3,(100,2)).astype(np.float32)
        values[rng.random((100,2))<.5]=0
        values[0,0]=np.float32(.1)
        values[1,0]=np.nextafter(np.float32(0),np.float32(1))
        values[2,0]=np.nextafter(np.float32(1),np.float32(2))
        oracle=CpuRuntime(W,np.array([0,1]),steps=100,kicks=values,input_encoding='kick_equivalent',
                          per_bin=10,trace=np.arange(8),p=sim.Params(th_jump=2,delay=.3),**features[extension])
        job=Job(p,package,shader_sha,out,rt=oracle,input_encoding=storage,seed=seed,
                scope='synthetic engineering qualification of preloaded fractional drive')
        job.submit()
        status=job.wait({'completed','failed','cancelled'},timeout_s=120)
        passed=status.get('state')=='completed' and status.get('source_commit')==source and job.parity()
        case=dict(seed=seed,storage=storage,extension=extension,job_id=job.id,
                  fixture_sha256=job.job['fixture_sha256'],source_commit=status.get('source_commit'),
                  passed=passed,state=status.get('state'))
        cases.append(case)
        (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
        assert passed, 'preloaded GPU drive parity failed'
    report['qualified']=len(cases)==16 and all(c['passed'] for c in cases)
finally:
    app_call(p,'DELETE',package,aumid)
    deadline=time.monotonic()+30
    while processes(p,'FlymsgWorker.exe') and time.monotonic()<deadline:
        time.sleep(.2)
    report['cleanup_worker_processes']=len(processes(p,'FlymsgWorker.exe'))
    p.close()
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'qualified':report['qualified'],'passed':len(cases),'worker_processes':report['cleanup_worker_processes']}))
