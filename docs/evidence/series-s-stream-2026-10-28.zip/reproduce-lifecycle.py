import hashlib
import json
import os
import time
from datetime import UTC, datetime
from pathlib import Path

import numpy as np
from scipy import sparse
from flymsg import sim
from flymsg.console import Device, Portal
from flymsg.console_hardstop import processes
from flymsg.console_lifecycle import app_call
from flymsg.console_runtime import ConsoleRuntime
from flymsg.native_acceptance import MEMBRANE, check
from flymsg.runtime import CpuRuntime

package = 'GianlucaMazza.FlymsgWorker_0.1.0.1_x64__g0p5dcfz4t9z4'
aumid = 'GianlucaMazza.FlymsgWorker_g0p5dcfz4t9z4!App'
source = '3cfa17f5c2d2247bef7ab7d5ae9dc212c2801817'
out = Path('runs/physical-stream-lifecycle')
out.mkdir(exist_ok=False)
report = dict(schema='flymsg.console_stream_lifecycle/v1', source_commit=source, package=package,
              recorded_at=datetime.now(UTC).isoformat(), passed=False,
              scope='synthetic neural stream recovery; no whole-body or hardware GPU-fault claim')
p = Portal()
device = Device(package=package, shader=Path(os.environ['FLYMSG_WORKER_SHADER']), portal=p)
W = sparse.csc_matrix(np.random.default_rng(83).integers(-20, 80, (8, 8)).astype(np.float32))
values = np.random.default_rng(84).uniform(0, 3, (100, 2)).astype(np.float32)

def fresh():
    return CpuRuntime(W, np.array([0, 1]), steps=100, per_bin=10,
                      kicks=np.zeros((0, 2), np.float32), input_encoding='kick_equivalent',
                      trace=np.arange(8), membrane=MEMBRANE,
                      graded=sim.Graded(idx=np.array([0, 1, 5, 6]), v_lo=-62, span=20, rate_hz=200))

def state(remote, wanted, phase):
    deadline = time.monotonic() + 60
    while True:
        status = device.status(remote._rel, out / f'{phase}-status.json')
        if status.get('state') in wanted:
            return status
        assert time.monotonic() < deadline, 'worker lifecycle state timeout'
        time.sleep(.1)

try:
    oracle = fresh()
    remote = ConsoleRuntime(fresh(), device, out, window_steps=17, source_commit=source)
    oracle.schedule_inputs(values)
    remote.schedule_inputs(values)
    oracle.advance_to(40)
    remote.advance_to(40)
    check(oracle, remote.snapshot())
    saved = out / 'checkpoint.npz'
    remote.checkpoint(saved)
    app_call(p, 'DELETE', package, aumid)
    stopped = state(remote, {'suspended'}, 'suspended')
    p.get(package, remote._rel, 'interrupted.bin', out / 'interrupted.bin')
    with np.load(saved, allow_pickle=False) as document:
        assert document['remote'].tobytes() == (out / 'interrupted.bin').read_bytes()
    app_call(p, 'POST', package, aumid)
    awaiting = state(remote, {'awaiting_recovery'}, 'restarted')
    try:
        remote.snapshot()
    except RuntimeError as exc:
        assert 'awaiting_recovery' in str(exc)
    else:
        raise AssertionError('interrupted stream was silently replayed')
    assert remote.step == 40
    report.update(suspend_step=40, interrupted_checkpoint_matches=True,
                  restart_requires_fresh_job=True, automatic_replay=False)
    remote.close()
    resumed = ConsoleRuntime(fresh(), device, out, window_steps=17, source_commit=source)
    resumed.restore(saved)
    # No rescheduling: future inputs must survive the host checkpoint envelope.
    oracle.advance_to(100)
    resumed.advance_to(100)
    check(oracle, resumed.snapshot())
    resumed.close()
    report.update(restored_step=100, future_schedule_preserved=True, restore_bit_parity=True)
    cancel = ConsoleRuntime(fresh(), device, out, window_steps=17, source_commit=source)
    cancel.schedule_inputs(values)
    cancel.advance_to(20)
    path = out / 'cancel.json'
    path.write_text(json.dumps(dict(schema='flymsg.worker_cancel/v1', job_id=cancel._job)))
    p.put(package, cancel._rel, path)
    observed = state(cancel, {'cancelled'}, 'cancelled')
    assert observed['step'] == 20
    try:
        cancel.advance_to(21)
    except RuntimeError as exc:
        assert 'cancelled' in str(exc)
    else:
        raise AssertionError('cancelled job advanced')
    assert cancel.step == 20
    cancel.close()
    report.update(cancel_step=20, cancelled_advance_refused=True, passed=True)
finally:
    try:
        app_call(p, 'DELETE', package, aumid)
        deadline = time.monotonic() + 30
        while processes(p, 'FlymsgWorker.exe') and time.monotonic() < deadline:
            time.sleep(.2)
        report['cleanup_worker_processes'] = len(processes(p, 'FlymsgWorker.exe'))
    finally:
        p.close()
        (out / 'report.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
