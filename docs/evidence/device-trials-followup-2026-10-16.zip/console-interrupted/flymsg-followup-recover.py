import base64,json,time
from pathlib import Path
from flymsg.console import Portal
out=Path('/home/gianluca/.cache/flymsg/qualification/series-s-followup-normal-b4bb56f')
pkg='GianlucaMazza.FlymsgWorker_0.1.0.0_x64__g0p5dcfz4t9z4'
report={'qualification':'not-scored; recover own stalled diagnostic attempt','started_unix':time.time(),'phases':[],'passed':False}
def save(phase):
 report['phases'].append(phase)
 (out/'recovery-diagnostic.json').write_text(json.dumps(report,indent=2)+'\n')
p=None
try:
 save('connect'); p=Portal()
 save('verify-epoch')
 expected=next(out.glob('qualification-epoch-*.json'))
 remote=out/'epoch-before-diagnostic-stop.json'
 p.get(pkg,'',expected.name,remote)
 if json.loads(remote.read_text())!=json.loads(expected.read_text()):raise RuntimeError('context changed; no stop requested')
 save('verify-exclusive-inbox')
 d=json.loads(p.curl('GET',f'/api/filesystem/apps/files?knownfolderid=LocalAppData&packagefullname={pkg}&path=%5CLocalState%5Cinbox'))
 known={s['job_id'] for s in json.loads(Path('/tmp/flymsg-followup-console-context.json').read_text())}|{'1616275d-7b3a-4b3b-a3e8-acf423be61fe'}
 if any(i['Name'] not in known for i in d.get('Items',[])):raise RuntimeError('new inbox entries; no stop requested')
 encoded=base64.b64encode(pkg.encode()).decode()
 save('force-stop-own-stalled-attempt')
 p.curl('DELETE',f'/api/taskmanager/app?package={encoded}&forcestop=yes')
 save('verify-epoch-after-stop');p.get(pkg,'',expected.name,out/'epoch-after-diagnostic-stop.json')
 if json.loads((out/'epoch-after-diagnostic-stop.json').read_text())!=json.loads(expected.read_text()):raise RuntimeError('context changed after diagnostic stop')
 save('restart')
 app=base64.b64encode(b'GianlucaMazza.FlymsgWorker_g0p5dcfz4t9z4!App').decode()
 p.curl('POST',f'/api/taskmanager/app?appid={app}&package={encoded}')
 save('finished');report['restarted']=True
except Exception as e:
 report.update(error_type=type(e).__name__,error=str(e));save('incomplete')
finally:
 if p:p.close()
 (out/'recovery-diagnostic.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report))
