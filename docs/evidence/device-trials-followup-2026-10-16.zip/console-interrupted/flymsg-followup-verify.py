import hashlib,json,sys,time
from pathlib import Path
sys.path.insert(0,'/home/gianluca/Workspace/experiments/flymsg/scripts')
import console_lifecycle as c
out=Path('/home/gianluca/.cache/flymsg/qualification/series-s-followup-normal-b4bb56f');folder=out/'1616275d-7b3a-4b3b-a3e8-acf423be61fe'
r={'scope':'CPU verification of completed diagnostic recovery; not lifecycle qualification','started_unix':time.time(),'passed':False}
try:
 r['output_sha256']=hashlib.sha256((folder/'output.bin').read_bytes()).hexdigest()
 if r['output_sha256']!=json.loads((folder/'result.json').read_text())['output_sha256']:raise RuntimeError('output checksum differs')
 rt=c.oracle('both');rt.advance_to(c.STEPS);c.check(rt,c.read_output(folder/'output.bin',folder/'fixture.bin'));r['passed']=True
except Exception as e:r.update(error_type=type(e).__name__,error=str(e))
r['finished_unix']=time.time();(out/'cpu-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
