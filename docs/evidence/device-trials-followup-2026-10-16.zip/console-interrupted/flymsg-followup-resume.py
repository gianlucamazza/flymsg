import importlib.util,json,sys,time
from pathlib import Path
root=Path('/home/gianluca/Workspace/experiments/flymsg');sys.path.insert(0,str(root/'scripts'))
import console_lifecycle as c
out=Path('/home/gianluca/.cache/flymsg/qualification/series-s-followup-normal-b4bb56f')
r={'qualification':'not-scored; diagnostic recovery after checkpoint stall','passed':False}
p=None
try:
 p=c.Portal();j=c.Job.__new__(c.Job);j.portal=p;j.package='GianlucaMazza.FlymsgWorker_0.1.0.0_x64__g0p5dcfz4t9z4';j.id='1616275d-7b3a-4b3b-a3e8-acf423be61fe';j.folder=out/j.id;j.rel='inbox\\'+j.id;j.steps=c.STEPS
 r['parked']=j.status()
 if r['parked'].get('source_commit')!='90249e45b2ecbccc126c4b0bee0a9ed5624c0026':raise RuntimeError('source changed; resume refused')
 if r['parked'].get('state') not in ('suspended','awaiting_recovery'):raise RuntimeError('no parked job; resume refused')
 (out/'diagnostic-resume.json').write_text(json.dumps(r,indent=2)+'\n')
 j.control('resume.json','flymsg.worker_resume/v1')
 r['final']=j.wait({'completed','failed','cancelled'},timeout_s=300)
 if r['final'].get('source_commit')!='90249e45b2ecbccc126c4b0bee0a9ed5624c0026':raise RuntimeError('source changed during recovery')
 if r['final'].get('state')=='completed':
  j.rt=c.oracle('both');r['parity']=j.parity();r['result']=j.result()
except Exception as e:r.update(error_type=type(e).__name__,error=str(e))
finally:
 if p:p.close()
 (out/'diagnostic-resume.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
