"""Verify extracted evidence. Optional --cpu ROOT rechecks the independent CPU oracle."""

import argparse, hashlib, json, sys
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument("--cpu", type=Path)
a = p.parse_args()
root = Path(__file__).resolve().parent
checks = json.loads((root / "checksums.json").read_text())
for name, sha in checks.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == sha, name
quest = json.loads((root / "quest/exclusion.json").read_text())
assert (
    quest["consecutive_invalid_preflights"] == 3
    and quest["qualification"] == "not-scored"
)
outputs = []
for name in ["console-normal", "console-force"]:
    directory = root / name
    report = json.loads((directory / "report.json").read_text())
    assert (
        report["throughput"]["parity"]
        and report["cancel"]["ok"]
        and report["stop_and_resume"]["parity"]
    )
    assert report["passed"] is (name == "console-normal")
    if name == "console-force":
        assert report["stop_and_resume"]["parked_as"] == "suspended"
    epoch = json.loads(next(directory.glob("qualification-epoch-*.json")).read_text())
    for phase in [
        "created",
        "before-stop",
        "after-stop",
        "after-restart",
        "after-recovery",
    ]:
        assert json.loads((directory / f"epoch-{phase}.json").read_text()) == epoch
    for result in directory.glob("*/result.json"):
        output = result.parent / "output.bin"
        assert (
            hashlib.sha256(output.read_bytes()).hexdigest()
            == json.loads(result.read_text())["output_sha256"]
        )
        outputs.append(output)
assert len(outputs) == 4
assert len({hashlib.sha256(p.read_bytes()).hexdigest() for p in outputs}) == 1
assert json.loads((root / "console-interrupted/cpu-verification.json").read_text())[
    "passed"
]
if a.cpu:
    sys.path[:0] = [str(a.cpu / "scripts"), str(a.cpu / "src")]
    import console_lifecycle as c

    runtime = c.oracle("both")
    runtime.advance_to(c.STEPS)
    for output in outputs:
        c.check(runtime, c.read_output(output, output.parent / "fixture.bin"))
for path in (root / "software").glob("*/oracle.json"):
    assert json.loads(path.read_text())["status"] == "pass", str(path)
print(
    json.dumps(
        {
            "checksummed_files": len(checks),
            "completed_outputs_identical": len(outputs),
            "cpu_reverified": bool(a.cpu),
            "quest_qualified": False,
            "normal_lifecycle_pass": True,
            "hard_stop_pass": False,
        }
    )
)
