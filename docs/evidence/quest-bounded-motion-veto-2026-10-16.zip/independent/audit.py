import json,pathlib,math,statistics,hashlib,sys
root=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else pathlib.Path(__file__).resolve().parent.parent/'campaign'
source=pathlib.Path(sys.argv[2]) if len(sys.argv)>2 else pathlib.Path(__file__).resolve().parent.parent/'source/viz_static'
results=[]
for blockfile in sorted(root.glob('page-*/block.json')):
 recorded=json.loads(blockfile.read_text())
 if not recorded.get('valid'): continue
 records=[]
 for arm,mode in enumerate(['original','paged','paged','original']):
  directory=blockfile.parent/f'arm-{arm}-{mode}'
  d=json.loads((directory/'trial.json').read_text())
  assert d['eligible'] is True and not d['reasons'] and d['cleanup_ok'] is True
  assert d['seconds']==30 and d['wall_ms']>=30000
  assert d['last']>=d['started_ms']+30000
  assert d['frames']==len(d['raw_intervals_ms'])+1
  assert d['source_sha256']
  for name,digest in d['source_sha256'].items():
   assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest
  expected='skeleton' if mode=='original' else 'skeleton-bounded'
  assert d['identity']['representation']==expected
  assert d['identity']['selected']==d['identity']['represented']==1128
  preflight=json.loads((blockfile.parent/f'arm-{arm}-preflight.jsonl').read_text().splitlines()[-1])
  assert preflight['device']['native_focus']['browser_focused'] is True
  assert preflight['browser']['source_verification'] is True
  intervals=d['raw_intervals_ms']; assert intervals and all(type(x) in (int,float) and math.isfinite(x) and x>0 for x in intervals)
  ordered=sorted(intervals); value=ordered[math.ceil(len(ordered)*.95)-1]
  if mode=='paged':
   frames=d['bounded_frames'];assert len(frames)==d['frames']
   for frame in frames:
    error=frame['maximum_error_px'];assert type(error) in (int,float) and math.isfinite(error) and 0<=error<=.5 and not frame.get('error')
    assert type(frame['source_indices']) is int and 0<=frame['source_indices']<=16517178
    if recorded['view']=='dense-all': assert frame['source_indices']==16517178
    assert type(frame['submitted_indices']) is int and 0<=frame['submitted_indices']<=frame['source_indices']
  records.append((d,value))
 first=records[0][0]
 for d,_ in records:
  for key in ['camera_profile','render_settings','source_sha256']:assert d[key]==first[key]
  for key in ['width','height','pixel_ratio','samples','selected','represented']:assert d['identity'][key]==first['identity'][key]
 original=(records[0][1]+records[3][1])/2;bounded=(records[1][1]+records[2][1])/2
 ratio=bounded/original
 assert math.isclose(ratio,recorded['summary']['ratio'],rel_tol=1e-12)
 results.append({'block':str(blockfile.parent.relative_to(root)),'original_p95_ms':original,'bounded_p95_ms':bounded,'ratio':ratio,'raw_certificates_checked':sum(len(d.get('bounded_frames',[])) for d,_ in records)})
report={'qualification':'completed blocks only; no final configuration or XR admission','status':'pass','blocks':results}
pathlib.Path(__file__).with_name('audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
