# Frozen febbfc2 Quest campaign

This archive closes the obsolete runtime campaign after the pre-registered
three-repeat negative veto, before replacing the selection scheduler.

16 MiB: dense median candidate/original p95 ratio 0.5926480373; anatomical-motion
median ratio 1.4091836735. All six ABBA blocks are valid, but the moving view's
40.9% median regression exceeds the 10% veto. There is no admitted page size.
Four MiB startup was excluded while Guardian held native focus. Sixty-four MiB
and the remaining views of vetoed 16 MiB were not timed; they are not negative
performance results. The operator decision was recorded before the third motion
repeat, and SIGINT was sent only after independent replay established the veto.

`campaign/` contains raw cadence, every bounded frame certificate, loaded-source
hashes, native focus receipts, static correctness readbacks and ordinary cleanup.
`classification.json` distinguishes vetoes, exclusions and physical XR limits.
The original collector logged DOM eligibility before applying native-focus
exclusion; replay must consult `device.native_focus` as well. Every completed
timing arm here had native Browser focus, a full 30-second window, matching
quality/content and source hashes, and successful per-arm cleanup.

Run with Python's standard library:

    python independent/audit.py

Optional arguments are the campaign directory and `source/viz_static` directory.
The replay checks all six blocks, all 2,087 bounded certificates, window duration,
original/bounded order, full selected neuron counts, quality and camera equality,
native focus, source hashes and p95 values recomputed from raw intervals.
It does not independently recompute the static geometric proof or compositor
frame drops, and it cannot establish physical XR or visual comfort.

`source/` preserves the measured host scripts, top-level viewer modules and the
pinned Three.js build for hash replay; the runtime commit identifies the complete
repository. This is not an exported browser site. `software/` preserves original
and bounded fixture passes plus the surface candidate/baseline preparation
failures and unchanged successful retry. Those fixtures contain two declared
source neurons and do not qualify complete-scene surface hardware behavior.

All cleanup operations succeeded. Virtual proximity was restored to DISABLED,
locks [0,0,0], and the original powered-display setting. The replacement runtime
is b4427da; no speed improvement or physical XR qualification follows from its
unit/software results. See the separately recorded replacement campaign.
