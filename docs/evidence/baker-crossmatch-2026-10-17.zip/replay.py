"""Conservative identity audit; no physiological response inputs or scoring."""

import argparse
import collections
import datetime
import hashlib
import json
import re
import struct
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

import pandas as pd

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("capture", type=Path)
parser.add_argument("table_s3", type=Path)
parser.add_argument("annotations", type=Path)
parser.add_argument("male_neurons", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()
D = args.capture
OUT = args.output
OUT.mkdir(parents=True, exist_ok=True)
ANN = args.annotations
record = json.loads((D / "summary.json").read_text())
for key, path in [
    ("table_s3", args.table_s3),
    ("flywire_annotations_v3.2.0", ANN),
    ("male_neurons", args.male_neurons),
]:
    assert (
        hashlib.sha256(path.read_bytes()).hexdigest()
        == record["sources"][key]["sha256"]
    ), key + " input hash mismatch"
ns = {"x": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
with zipfile.ZipFile(args.table_s3) as z:
    strings = [
        "".join(e.itertext())
        for e in ET.fromstring(z.read("xl/sharedStrings.xml")).findall("x:si", ns)
    ]
    table = []
    for row in ET.fromstring(z.read("xl/worksheets/sheet1.xml")).findall(
        ".//x:row", ns
    ):
        values = {
            re.sub(r"\d", "", c.get("r")): strings[int(c.find("x:v", ns).text)]
            if c.get("t") == "s"
            else c.findtext("x:v", default="", namespaces=ns)
            for c in row
        }
        if int(row.get("r")) == 1:
            assert (
                values["A"] == "Neuron name"
                and values["C"] == "Root ID (synaptic connectivity)"
                and values["D"] == "Root ID (contact analysis)"
            )
            continue
        name = values.get("A", "")
        typ = re.sub(r"_[LR]\d*$", "", name)
        if typ.startswith("B1-"):
            typ = "B1"
        if typ.startswith("WED-VLP-"):
            typ = "WED-VLP"
        if typ in {c["baker_type"] for c in record["classes"]}:
            table.append(
                {
                    "row": int(row.get("r")),
                    "name": name,
                    "coordinates": values["B"],
                    "v11": values["C"],
                    "v274": values["D"],
                    "baker_type": typ,
                }
            )
rows = table
assert len(rows) == 404
metadata = json.loads((D / "api/materialization-783.json").read_text())
assert (
    metadata["version"] == 783
    and metadata["datastack"] == "flywire_fafb_public"
    and metadata["valid"]
)
assert metadata["time_stamp"] == "2023-09-30T05:10:01.441140"
TS = datetime.datetime(2023, 9, 30, 5, 10, 1, 441140, tzinfo=datetime.UTC).timestamp()
anchors = {x["row"]: x for x in json.loads((D / "anchors.json").read_text())}
roots = sorted({int(r[k]) for r in rows for k in ("v11", "v274") if r[k].isdigit()})
latest = dict(
    zip(
        roots, json.loads((D / "api/latest.json").read_text())["is_latest"], strict=True
    )
)
created = dict(
    zip(
        roots,
        json.loads((D / "api/timestamps.json").read_text())["timestamp"],
        strict=True,
    )
)
nodes = {}
adj = collections.defaultdict(set)
for p in sorted((D / "api").glob("lineage-*.json")):
    g = json.loads(p.read_text())
    for n in g["nodes"]:
        if n["timestamp"] <= TS:
            nodes[n["id"]] = n
    for e in g["links"]:
        adj[e["source"]].add(e["target"])


def successors(root):
    if created[root] > TS:
        return []
    if latest[root]:
        return [root]
    if root not in nodes:
        return []
    seen = {root}
    q = [root]
    while q:
        for v in adj[q.pop()]:
            if v in nodes and v not in seen:
                seen.add(v)
                q.append(v)
    return sorted(n for n in seen if not (adj[n] & nodes.keys()))


mapping = {str(r): successors(r) for r in roots}
(OUT / "root-successors.json").write_text(json.dumps(mapping, indent=2))
ann = pd.read_csv(ANN, sep="\t", dtype=str, low_memory=False).fillna("")
assert not ann.root_id.duplicated().any()
a = ann.set_index("root_id").to_dict("index")
male = pd.read_parquet(args.male_neurons).fillna("")
tokens = collections.defaultdict(list)
for r in male.to_dict("records"):
    for t in re.split(r"[,;]\s*", r["flywireType"]):
        if t:
            tokens[t].append(r)


def male_matches(t):
    return [
        {
            "body_id": str(r["bodyId"]),
            "type": r["type"],
            "flywire_type": r["flywireType"],
            "dimorphism": r["dimorphism"],
            "fru_dsx": r["fruDsx"],
        }
        for r in tokens[t]
    ]


out = []
for r in rows:
    ids = {k: mapping.get(r[k], []) for k in ("v11", "v274")}
    anchor = anchors[r["row"]]
    root = int(anchor["root_783"])
    union = [root]
    status = (
        "root_unique"
        if all(root in v for v in ids.values())
        else "anchor_lineage_mismatch"
    )
    matches = []
    for x in union:
        an = a.get(str(x))
        matches.append(
            {
                "root_783": str(x),
                "flywire_type": an["cell_type"] if an else "",
                "flywire_dimorphism": an["dimorphism"] if an else "",
                "supervoxel_id": an["supervoxel_id"] if an else "",
                "male": male_matches(an["cell_type"]) if an and an["cell_type"] else [],
            }
        )
    if status == "root_unique":
        if not matches[0]["flywire_type"]:
            status = "annotation_missing"
        elif not matches[0]["male"]:
            status = "male_token_missing"
        elif not any(m["type"] for m in matches[0]["male"]):
            status = "male_type_missing"
        else:
            status = "complete"
    out.append(
        {
            **r,
            "anchor": anchor,
            "successors": {k: [str(x) for x in v] for k, v in ids.items()},
            "status": status,
            "matches": matches,
        }
    )
(OUT / "rows.json").write_text(json.dumps(out, indent=2))
classes = record["classes"]
summary = []
for c in classes:
    name = c["baker_type"]
    rr = [r for r in out if r["baker_type"] == name]
    count = dict(collections.Counter(r["status"] for r in rr))
    types = sorted(
        {m["flywire_type"] for r in rr for m in r["matches"] if m["flywire_type"]}
    )
    mt = sorted(
        {v["type"] for r in rr for m in r["matches"] for v in m["male"] if v["type"]}
    )
    dims = sorted(
        {
            v["dimorphism"] or "unannotated"
            for r in rr
            for m in r["matches"]
            for v in m["male"]
        }
    )
    status = (
        "absent"
        if not rr
        else "complete"
        if count.get("complete") == len(rr)
        else "partial"
    )
    s = {
        "baker_type": name,
        "source_neurons": len(rr),
        "status": status,
        "row_status_counts": count,
        "candidate_flywire_types": types,
        "candidate_male_types": mt,
        "male_dimorphism": dims,
    }
    summary.append(s)
    print(name, len(rr), status, count, "=>", ",".join(mt), flush=True)
(OUT / "classes.json").write_text(json.dumps(summary, indent=2))
print("class status", collections.Counter(r["status"] for r in summary))
print("row status", collections.Counter(r["status"] for r in out))

assert all(r["status"] != "anchor_lineage_mismatch" for r in out)
assert len(out) == len(anchors) == 404
anchor_binary = (D / "api/anchor-roots-783.bin").read_bytes()
assert len(anchor_binary) == 404 * 8
assert list(struct.unpack("<" + "Q" * 404, anchor_binary)) == [
    int(anchors[r["row"]]["root_783"]) for r in rows
]
for r in rows:
    assert anchors[r["row"]]["name"] == r["name"]
# Independent server validity oracle, captured separately from lineage/anchor derivation.
anchor_roots = sorted({int(r["anchor"]["root_783"]) for r in out})
validity = json.loads((D / "api/anchor-is-latest-783.json").read_text())["is_latest"]
assert len(validity) == len(anchor_roots) and all(validity)
# A second set of supervoxels, from the published annotation table rather than S3 points.
pairs = sorted(
    {
        (int(m["supervoxel_id"]), int(m["root_783"]))
        for r in out
        for m in r["matches"]
        if m["supervoxel_id"]
    }
)
raw = (D / "api/annotation-roots-783.bin").read_bytes()
assert len(raw) == 8 * len(pairs)
assert list(struct.unpack("<" + "Q" * len(pairs), raw)) == [p[1] for p in pairs]
for actual, expected in zip(summary, record["classes"], strict=True):
    for key in (
        "baker_type",
        "source_neurons",
        "status",
        "row_status_counts",
        "candidate_flywire_types",
        "candidate_male_types",
        "male_dimorphism",
    ):
        assert actual[key] == expected[key], (actual["baker_type"], key)
assert (
    dict(collections.Counter(r["status"] for r in out))
    == record["counts"]["row_status"]
)
print(
    "PASS: input hashes, all 404 anchors, both source lineages, independent root/annotation oracles and class counts"
)
