# Baker identity audit, 2026-10-17

Anatomical metadata only. No response files, model scores, credentials, original
workbooks or full annotation tables are included. The two inputs below are
retrieved directly from their publishers; keep source files outside public
repositories. Cite Baker et al. 2022, Schlegel et al. 2024 and Berg et al. 2026.

## Offline replay

1. Download the original Table S3, not a spreadsheet re-save:
   https://ars.els-cdn.com/content/image/1-s2.0-S0960982222009782-mmc2.xlsx
2. Download the pinned FlyWire annotation TSV:
   https://raw.githubusercontent.com/flyconnectome/flywire_annotations/v3.2.0/supplemental_files/Supplemental_file1_neuron_annotations.tsv
3. Use the MaleCNS `data/neurons.parquet` matching `summary.json`'s input hash.
4. With Python and pandas (the flymsg development environment suffices), run:

   python replay.py CAPTURE_DIR TABLE_S3.xlsx ANNOTATIONS.tsv MALE_NEURONS.parquet OUTPUT_DIR

`CAPTURE_DIR` is the directory containing this README; `OUTPUT_DIR` is a new local
scratch directory. No token or network is needed. Replay verifies hashes before
joining, reconstructs source classes and historical successors from raw graphs,
checks anchors against both source lineages, recomputes all male-body/type joins,
and verifies the separately captured server validity/annotation-supervoxel
oracles. It reconciles all class/status/type lists against the summary. IDs are
read as exact strings from the workbook XML. Source responses are not inputs.

## Acquisition and records

- `summary.json`: rules, exact input hashes, 28 class summaries and count controls.
- `matches.json`: one identity result per selected Table S3 reconstruction,
  original worksheet row, both historical roots and all target male body IDs.
  `complete` means at least one named male type for that reconstruction. Blank
  male type names remain blank. Class coverage can be one-to-many.
- `anchors.json`: original source row/name, sampled supervoxel, root at version 783.
  Original coordinates are obtained from the hashed source workbook on replay.
- `api/timestamps.json`, `api/latest.json`: POST `root_timestamps` and
  `is_latest_roots` for the sorted union of the 556 source roots. `latest` uses
  the fixed target timestamp, not today's graph.
- `api/lineage-NNN.json`: POST `lineage_graph_multiple` with sorted source roots
  in batches of 8 (`NNN` is the zero-based start offset). Request body is
  `{"root_ids": [...]}` and `timestamp_future=1696050601.44114`.
  All graph operations are retained as returned; replay trims future nodes.
- `api/anchor-roots-783.bin`: POST `roots_binary` at the target timestamp, little
  endian uint64 request/response; anchors are in source worksheet order.
- `api/anchor-is-latest-783.json`: POST `is_latest_roots` on sorted unique anchor
  roots at that timestamp, a separate check from the lineage computation.
- `api/annotation-roots-783.bin`: `roots_binary` response for published annotation
  supervoxels, sorted unique `(supervoxel, expected_root)` pairs. All 404 map to
  the expected root. In 387 cases the annotation supervoxel differs from S3's
  coordinate-derived supervoxel, providing an independent anatomical anchor.
- `api/materialization-783.json`: GET metadata from the materialization service.
- `segmentation-info.json`: volume metadata (source, offsets, resolutions).
- `verification.json`: independent-query summary.

Segmentation API base:
https://prod.flywire-daf.com/segmentation/api/v1/table/flywire_public/

Materialization metadata URL:
https://prod.flywire-daf.com/materialize/api/v2/datastack/flywire_fafb_public/version/783

Target timestamp: 2023-09-30T05:10:01.441140 UTC (1696050601.44114).
POST JSON bodies use `application/json`; `roots_binary` uses
`application/octet-stream`. Requests authenticate through a locally stored CAVE
token; tokens and request headers are excluded from this archive.

S3 points were read using CloudVolume with `agglomerate=False`, `mip=0`,
`use_https=True`, then `download_point(xyz, size=1,
coord_resolution=[4,4,40], agglomerate=False)`. The static watershed has base
resolution [16,16,40] nm. Binary root lookup is pinned to the target timestamp.
A zero-length first binary response was rejected; only successful length-checked
responses are retained. No identity is selected from lineage size, name similarity
or a first-match fallback. Missing/ambiguous paths cannot become complete.

`SHA256SUMS` covers every archive member except itself. Source acquisition hashes
are in `summary.json`. The source workbook is not included or modified.
