"""Verify immutable artifacts; optional REPOSITORY rechecks CPU and float state bits.
Usage: python verify.py EXTRACTED_DIRECTORY [CLEAN_REPOSITORY]
"""
import hashlib, json, sys
from collections import Counter
from pathlib import Path
root=Path(sys.argv[1])
manifest=json.loads((root/'inventory.json').read_text())
for name,digest in manifest.items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
report=json.loads((root/'report.json').read_text())
lineage=json.loads((root/'lineage.json').read_text())
def key(c): return c['seed'],c['adaptation'],c['silenced'],c['extension']
def expected(exts):return Counter((s,a,b,e) for s in (3,7,19) for a in (0.,2.) for b in (False,True) for e in exts)
assert Counter(map(key,report['cases']))==expected(('none','graded','gap','spikelets','both','gap-all-free'))
assert Counter(map(key,report['unsupported']))==expected(('gap-continuous-refractory',))
assert all(c['reason']=='native continuous-clamp electrical coupling with refractory cells is unqualified' for c in report['unsupported'])
assert all(c['parity'] and c['state']=='completed' and c['source_commit']==lineage['worker_source_commit'] for c in report['cases'])
folders={hashlib.sha256(f.read_bytes()).hexdigest():f.parent for f in root.glob('*/fixture.bin')}
for case in report['cases']:
 folder=folders[case['fixture_sha256']]
 job=json.loads((folder/'job.json').read_text())
 result=json.loads((folder/'result.json').read_text())
 assert job['shader_sha256']==lineage['shader_sha256']==report['shader_sha256']
 assert hashlib.sha256((folder/'output.bin').read_bytes()).hexdigest()==result['output_sha256']==case['output_sha256']
if len(sys.argv)>2:
 import numpy as np
 repo=Path(sys.argv[2]).resolve()
 sys.path.insert(0,str(repo/'src'));sys.path.insert(0,str(repo/'scripts'))
 from console_gpu_parity import fixtures,EXTENSIONS
 from native_acceptance import check
 from flymsg.native import read_output
 oracles={k:rt for k,rt in fixtures(tuple(EXTENSIONS))}
 for case in report['cases']:
  rt=oracles[key(case)];rt.advance_to(1000)
  folder=folders[case['fixture_sha256']]
  actual=read_output(folder/'output.bin',folder/'fixture.bin')
  check(rt,actual)
  state=rt.snapshot()
  for name in ('v','g','th','graded_ring','graded_vsum','gap_pulse'):
   if name in state:
    np.testing.assert_array_equal(np.ascontiguousarray(actual[name]).view(np.uint8),np.ascontiguousarray(state[name]).view(np.uint8),err_msg=name)
 print('72 GPU outputs match CPU oracle, including floating-point state bytes')
print('Archive hashes, exact case/refusal matrices, source/shader and output identities verified')
